import './qazan-store.css';
import { type FormEvent, useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft, Check, ChevronDown, Crown, Heart, Headphones, MapPin, Menu,
  MessageCircle, Minus, PackageCheck, Plus, Search, Settings2, ShieldCheck,
  ShoppingBag, Scale, Trash2, Truck, UserRound, X,
} from 'lucide-react';

type Product = {
  id: string;
  name: string;
  category: string;
  price: number;
  description: string;
  image: string;
  tag?: string;
};
type CartItem = { productId: string; quantity: number };
type StoreCategory = { id: string; label: string; image: string; sourceCategories: string[] };

const baseUrl = import.meta.env.BASE_URL.endsWith('/')
  ? import.meta.env.BASE_URL
  : `${import.meta.env.BASE_URL}/`;
const assetUrl = (path: string) => `${baseUrl}${path.replace(/^\/+/, '')}`;

const products: Product[] = [
  { id: 'stoneware-cup', name: 'Everyday Stoneware Cup', category: 'Kitchen', price: 28, description: 'Hand-finished ceramic, made for slow mornings.', image: assetUrl('products/stoneware-cup.jpg'), tag: 'Bestseller' },
  { id: 'linen-tote', name: 'Market Linen Tote', category: 'Carry', price: 34, description: 'Roomy, sturdy linen for all the little errands.', image: assetUrl('products/linen-tote.jpg'), tag: 'Small batch' },
  { id: 'brass-candlestick', name: 'Quiet Hour Candle', category: 'Home', price: 42, description: 'Warm notes in a softly glowing glass vessel.', image: assetUrl('products/quiet-hour-candle.jpg') },
  { id: 'botanical-soap', name: 'Garden Body Oil', category: 'Body', price: 18, description: 'A botanical blend for a slower, softer skin ritual.', image: assetUrl('products/garden-body-oil.jpg'), tag: 'New' },
  { id: 'oak-board', name: 'Weeknight Linen Napkin', category: 'Kitchen', price: 24, description: 'Soft natural linen to bring ease to the dinner table.', image: assetUrl('products/market-table-linens.jpg') },
  { id: 'wool-throw', name: 'Woven Wool Rug', category: 'Home', price: 96, description: 'A soft, textured layer woven in easygoing tones.', image: assetUrl('products/woven-wool-rug.jpg'), tag: 'Thoughtful pick' },
  { id: 'glass-vase', name: 'Pampas & Glass Vase', category: 'Home', price: 46, description: 'Dried seasonal stems in a softly tinted glass vessel.', image: assetUrl('products/pampas-arrangement.jpg') },
  { id: 'tea-towel', name: 'Shared Table Cup Duo', category: 'Kitchen', price: 32, description: 'Two everyday ceramic cups for a slower shared moment.', image: assetUrl('products/shared-table-cups.jpg') },
];

const arabicNames: Record<string, string> = {
  'stoneware-cup': 'كوب سيراميك يومي',
  'linen-tote': 'حقيبة كتانية للسوق',
  'brass-candlestick': 'شمعة الساعة الهادئة',
  'botanical-soap': 'زيت الجسم النباتي',
  'oak-board': 'منديل كتاني للمائدة',
  'wool-throw': 'سجادة صوف منسوجة',
  'glass-vase': 'مزهرية زجاجية مع زهور مجففة',
  'tea-towel': 'طقم كوبين للمائدة',
};
const displayName = (product: Product) => arabicNames[product.id] ?? product.name;
const arabicDescriptions: Record<string, string> = {
  'stoneware-cup': 'فخار مصقول يدوياً لبدايات صباح هادئة.',
  'linen-tote': 'حقيبة كتانية واسعة ومتينة للمشاوير اليومية.',
  'brass-candlestick': 'شمعة بأجواء دافئة في وعاء زجاجي هادئ.',
  'botanical-soap': 'مزيج نباتي لروتين عناية ألطف وأكثر هدوءاً.',
  'oak-board': 'مناديل كتانية ناعمة لمائدة يومية مريحة.',
  'wool-throw': 'سجادة صوف منسوجة بملمس ناعم وألوان هادئة.',
  'glass-vase': 'زهور مجففة موسمية في مزهرية زجاجية بلون هادئ.',
  'tea-towel': 'كوبان سيراميك للاستخدام اليومي ومشاركة أوقات هادئة.',
};
const displayDescription = (product: Product) => arabicDescriptions[product.id] ?? product.description;
const tagNames: Record<string, string> = {
  Bestseller: 'الأكثر مبيعاً',
  'Small batch': 'دفعة محدودة',
  New: 'جديد',
  'Thoughtful pick': 'اختيار بعناية',
};

const categories: StoreCategory[] = [
  { id: 'books', label: 'الكتب', image: assetUrl('categories/books.webp'), sourceCategories: [] },
  { id: 'sports', label: 'الألعاب والرياضة', image: assetUrl('categories/sports.webp'), sourceCategories: [] },
  { id: 'personal-care', label: 'المستلزمات الشخصية', image: assetUrl('categories/personal-care.webp'), sourceCategories: ['Body'] },
  { id: 'perfumes', label: 'العطور', image: assetUrl('categories/perfumes.webp'), sourceCategories: [] },
  { id: 'groceries', label: 'المواد الغذائية', image: assetUrl('categories/groceries.webp'), sourceCategories: [] },
  { id: 'clothing', label: 'الملابس', image: assetUrl('categories/clothing.webp'), sourceCategories: ['Carry'] },
  { id: 'home', label: 'الأدوات المنزلية', image: assetUrl('categories/home.webp'), sourceCategories: ['Kitchen', 'Home'] },
  { id: 'electronics', label: 'الإلكترونيات', image: assetUrl('categories/electronics.webp'), sourceCategories: [] },
];

const CART_KEY = 'common-goods-cart-v1';
const PHONE_KEY = 'common-goods-whatsapp-number-v1';
const FAVORITES_KEY = 'qazan-store-favorites-v1';
const COMPARE_KEY = 'qazan-store-compare-v1';
const money = (amount: number) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(amount);

function safeRead<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) as T : fallback;
  } catch {
    return fallback;
  }
}

function storedCart(): CartItem[] {
  const parsed = safeRead<unknown>(CART_KEY, []);
  if (!Array.isArray(parsed)) return [];
  return parsed.filter((item): item is CartItem =>
    typeof item?.productId === 'string' &&
    products.some((product) => product.id === item.productId) &&
    Number.isInteger(item?.quantity) && item.quantity > 0);
}

function storedProductIds(key: string): string[] {
  const parsed = safeRead<unknown>(key, []);
  return Array.isArray(parsed) ? parsed.filter((id): id is string => typeof id === 'string' && products.some((product) => product.id === id)) : [];
}

function whatsappHref(phone: string, message: string) {
  return `https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;
}

export default function Variant() {
  const [cart, setCart] = useState<CartItem[]>(storedCart);
  const [phone, setPhone] = useState(() => safeRead<string>(PHONE_KEY, ''));
  const [phoneDraft, setPhoneDraft] = useState(phone);
  const [activeCategory, setActiveCategory] = useState('all');
  const [search, setSearch] = useState('');
  const [cartOpen, setCartOpen] = useState(false);
  const [favoritesOpen, setFavoritesOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [compareOpen, setCompareOpen] = useState(false);
  const [favorites, setFavorites] = useState<string[]>(() => storedProductIds(FAVORITES_KEY));
  const [compared, setCompared] = useState<string[]>(() => storedProductIds(COMPARE_KEY));
  const [toast, setToast] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => { localStorage.setItem(CART_KEY, JSON.stringify(cart)); }, [cart]);
  useEffect(() => { localStorage.setItem(PHONE_KEY, phone); }, [phone]);
  useEffect(() => { localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites)); }, [favorites]);
  useEffect(() => { localStorage.setItem(COMPARE_KEY, JSON.stringify(compared)); }, [compared]);
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const filteredProducts = useMemo(() => {
    const query = search.trim().toLowerCase();
    const selected = categories.find((category) => category.id === activeCategory);
    return products.filter((product) => {
      const categoryMatch = activeCategory === 'all' || !!selected?.sourceCategories.includes(product.category);
      const searchable = `${product.name} ${displayName(product)} ${product.category} ${product.description} ${displayDescription(product)}`.toLowerCase();
      return categoryMatch && (!query || searchable.includes(query));
    });
  }, [activeCategory, search]);
  const cartProducts = cart.flatMap((item) => {
    const product = products.find((entry) => entry.id === item.productId);
    return product ? [{ ...item, product }] : [];
  });
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const cartTotal = cartProducts.reduce((total, item) => total + item.product.price * item.quantity, 0);
  const favoriteProducts = favorites.map((id) => products.find((product) => product.id === id)).filter((product): product is Product => !!product);
  const comparedProducts = compared.map((id) => products.find((product) => product.id === id)).filter((product): product is Product => !!product);

  function addToCart(product: Product) {
    setCart((current) => {
      const found = current.find((item) => item.productId === product.id);
      return found
        ? current.map((item) => item.productId === product.id ? { ...item, quantity: item.quantity + 1 } : item)
        : [...current, { productId: product.id, quantity: 1 }];
    });
    setToast(`تمت إضافة ${displayName(product)} إلى السلة`);
  }
  function changeQuantity(productId: string, delta: number) {
    setCart((current) => current.map((item) => item.productId === productId ? { ...item, quantity: item.quantity + delta } : item).filter((item) => item.quantity > 0));
  }
  function removeFromCart(productId: string) {
    setCart((current) => current.filter((item) => item.productId !== productId));
    setToast('تم حذف المنتج من السلة');
  }
  function savePhone(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPhone(phoneDraft.trim());
    setSettingsOpen(false);
    setToast(phoneDraft.trim() ? 'تم حفظ الرقم في هذا المتصفح' : 'تم مسح الرقم المحفوظ');
  }
  function openSettings() {
    setPhoneDraft(phone);
    setSettingsOpen(true);
  }
  function toggleFavorite(product: Product) {
    const isSaved = favorites.includes(product.id);
    setFavorites((current) => isSaved ? current.filter((id) => id !== product.id) : [...current, product.id]);
    setToast(isSaved ? 'تمت الإزالة من المفضلة المحفوظة محلياً' : 'تمت الإضافة إلى المفضلة المحفوظة محلياً');
  }
  function toggleCompare(product: Product) {
    setCompared((current) => {
      if (current.includes(product.id)) return current.filter((id) => id !== product.id);
      if (current.length >= 3) {
        setToast('يمكن مقارنة ٣ منتجات كحد أقصى');
        return current;
      }
      setToast('أضيف المنتج إلى المقارنة المحلية');
      return [...current, product.id];
    });
  }
  function cartMessage() {
    const lines = cartProducts.map(({ product, quantity }) => `• ${displayName(product)} × ${quantity} — ${money(product.price * quantity)}`);
    return `مرحباً متجر قزان، أرغب بالاستفسار عن الطلب التالي:\n\n${lines.join('\n')}\n\nالإجمالي المقدر: ${money(cartTotal)}\n\nيرجى تأكيد التوفر وتفاصيل التوصيل والدفع.`;
  }
  function productMessage(product: Product) {
    return `مرحباً متجر قزان، أود الاستفسار عن ${displayName(product)} بسعر ${money(product.price)}. هل المنتج متوفر؟`;
  }

  return (
    <main className="qazan-store" dir="rtl">
      <div className="qazan-topline" data-testid="text-store-announcement">
        <div className="qazan-wrap topline-inner">
          <div className="top-location"><MapPin size={13} /><span>اليمن</span><span className="top-separator">|</span><span>تفاصيل التوصيل عبر واتساب</span></div>
          <div className="top-actions">
            <button className="disabled-account" type="button" disabled aria-disabled="true" title="تسجيل الدخول غير متاح في هذا النموذج"><UserRound size={12} /> تسجيل الدخول</button>
            <i />
            <button type="button" onClick={() => setFavoritesOpen(true)} aria-label="فتح المفضلة" data-testid="button-open-favorites">المفضلة <Heart size={12} /></button>
            <i />
            <button type="button" onClick={() => setCompareOpen(true)} aria-label="فتح المقارنة">مقارنة المنتجات <Scale size={13} /></button>
            <i />
            <a href="#footer" data-testid="link-contact">تواصل معنا</a>
          </div>
        </div>
      </div>

      <header className="qazan-header">
        <div className="qazan-wrap header-main">
          <a className="brand-logo" href="#top" aria-label="متجر قزان - الرئيسية" data-testid="link-store-home">
            <img src={assetUrl('branding/qazan-logo.webp')} alt="شعار متجر قزان" />
          </a>
          <label className="qazan-search">
            <Search size={17} aria-hidden="true" />
            <input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="ابحث عن منتج، فئة أو علامة تجارية..." aria-label="ابحث في المنتجات" data-testid="input-search-products" />
            {search && <button type="button" aria-label="مسح البحث" onClick={() => setSearch('')}><X size={15} /></button>}
          </label>
          <div className="main-actions">
            <button className="header-action" type="button" onClick={() => setCartOpen(true)} aria-label={`فتح السلة، ${cartCount} منتجات`} data-testid="button-open-cart">
              <span className="action-icon"><ShoppingBag size={19} /><b data-testid="text-cart-count">{cartCount}</b></span><span>السلة</span>
            </button>
            <button className="header-action" type="button" onClick={() => setFavoritesOpen(true)} aria-label="عرض المفضلة المحلية" data-testid="button-header-favorites">
              <Heart size={19} /><span>المفضلة</span>
            </button>
            <button className="header-action compare-action" type="button" onClick={() => setCompareOpen(true)} aria-label="مقارنة المنتجات">
              <Scale size={19} /><span>المقارنة</span>
            </button>
            <button className="mobile-menu" type="button" aria-label="فتح القائمة" aria-expanded={mobileMenuOpen} onClick={() => setMobileMenuOpen((open) => !open)}><Menu size={21} /></button>
          </div>
        </div>
        <nav className={`qazan-nav${mobileMenuOpen ? ' nav-open' : ''}`} aria-label="التنقل الرئيسي">
          <div className="qazan-wrap nav-inner">
            <a className="nav-home" href="#top" onClick={() => setMobileMenuOpen(false)}>الرئيسية</a>
            <a href="#categories" onClick={() => setMobileMenuOpen(false)}>التصنيفات <ChevronDown size={13} /></a>
            <a href="#shop" onClick={() => { setActiveCategory('all'); setMobileMenuOpen(false); }} data-testid="link-shop">جميع المنتجات</a>
            <a href="#shop" onClick={() => { setSearch(''); setMobileMenuOpen(false); }}>الكتالوج</a>
            <a href="#services" onClick={() => setMobileMenuOpen(false)} data-testid="link-our-way">عن المتجر</a>
            <a href="#footer" onClick={() => setMobileMenuOpen(false)}>تواصل معنا</a>
            <button type="button" className="mobile-only-nav" onClick={() => { setFavoritesOpen(true); setMobileMenuOpen(false); }} data-testid="button-mobile-favorites"><Heart size={14} /> المفضلة</button>
            <button type="button" className="mobile-only-nav" onClick={() => { setCompareOpen(true); setMobileMenuOpen(false); }} data-testid="button-mobile-compare"><Scale size={14} /> مقارنة المنتجات</button>
            <button type="button" className="nav-whatsapp" onClick={openSettings} data-testid="button-whatsapp-settings"><Settings2 size={14} /> إعداد واتساب</button>
          </div>
        </nav>
      </header>

      <section className="qazan-hero qazan-wrap" id="top" aria-label="التوصيل في اليمن">
        <img className="hero-photo" src={assetUrl('branding/qazan-yemen-delivery.webp')} alt="مندوب توصيل في أحد شوارع اليمن" />
        <div className="hero-shade" />
        <div className="hero-copy">
          <span className="hero-kicker">كل ما تحتاجه في مكان واحد</span>
          <h1>تسوّق بكل سهولة<br /><em>من متجر قزان</em></h1>
          <p>منتجات متنوعة · أسعار واضحة · تواصل مباشر عبر واتساب</p>
          <a className="hero-cta" href="#shop" data-testid="link-browse-collection">تسوّق الآن <ArrowLeft size={16} /></a>
        </div>
          <div className="hero-delivery-tag"><Truck size={24} /><span><strong>التوصيل في اليمن</strong><small>التفاصيل عبر واتساب</small></span></div>
        <div className="hero-dots" aria-hidden="true"><i className="selected" /><i /><i /><i /></div>
      </section>

      <section className="category-section qazan-wrap" id="categories" aria-label="تسوق حسب الفئة">
        <div className="category-intro">
          <span className="intro-mark" aria-hidden="true">ق</span>
          <span>تسوّق<br />حسب الفئة</span>
        </div>
        <div className="category-rail">
          {categories.map((category) => (
            <button key={category.id} type="button" className={`category-tile${activeCategory === category.id ? ' selected' : ''}`} onClick={() => { setActiveCategory(category.id); document.getElementById('shop')?.scrollIntoView({ behavior: 'smooth' }); }} aria-pressed={activeCategory === category.id} data-testid={`button-category-${category.id}`}>
              <span className="category-image"><img src={category.image} alt="" loading="lazy" /></span>
              <span className="category-label">{category.label}</span>
              <ArrowLeft className="category-arrow" size={13} aria-hidden="true" />
            </button>
          ))}
        </div>
        <button className="all-categories" type="button" onClick={() => { setActiveCategory('all'); document.getElementById('shop')?.scrollIntoView({ behavior: 'smooth' }); }} data-testid="button-category-everything">عرض الكل <ArrowLeft size={14} /></button>
      </section>

      <section className="qazan-wrap shop-layout" id="shop" aria-labelledby="shop-title">
        <div className="catalog-column">
          <div className="catalog-heading">
            <div className="title-with-crown"><span className="gold-crown" aria-hidden="true"><Crown size={20} /></span><div><span className="section-overline">كتالوج متجر قزان</span><h2 id="shop-title">{activeCategory === 'all' ? 'المنتجات المميزة' : categories.find((category) => category.id === activeCategory)?.label}</h2></div></div>
            <span className="result-count" data-testid="text-product-count">{filteredProducts.length} منتجات</span>
          </div>
          <div className="catalog-tools">
            <div className="active-category-label">{activeCategory === 'all' ? 'تصفّح المنتجات المتاحة' : `الفئة: ${categories.find((category) => category.id === activeCategory)?.label}`}</div>
            <button className="reset-filter" type="button" onClick={() => { setActiveCategory('all'); setSearch(''); }} data-testid="button-clear-filters">عرض جميع المنتجات</button>
          </div>
          <div className="product-grid" data-testid="grid-products">
            {filteredProducts.length ? filteredProducts.map((product) => (
              <article className="qazan-product" key={product.id} data-testid={`card-product-${product.id}`}>
                <div className="product-photo">
                  <img src={product.image} alt={displayName(product)} loading="lazy" data-testid={`img-product-${product.id}`} />
                  {product.tag && <span className="product-flag">{tagNames[product.tag] ?? product.tag}</span>}
                  <div className="product-quick-actions">
                    <button type="button" onClick={() => toggleFavorite(product)} aria-label={favorites.includes(product.id) ? `إزالة ${displayName(product)} من المفضلة` : `إضافة ${displayName(product)} إلى المفضلة`} aria-pressed={favorites.includes(product.id)} data-testid={`button-favorite-${product.id}`}><Heart size={16} fill={favorites.includes(product.id) ? 'currentColor' : 'none'} /></button>
                    <button type="button" onClick={() => toggleCompare(product)} aria-label={compared.includes(product.id) ? `إزالة ${displayName(product)} من المقارنة` : `إضافة ${displayName(product)} للمقارنة`} aria-pressed={compared.includes(product.id)} data-testid={`button-compare-${product.id}`}><Scale size={16} /></button>
                  </div>
                </div>
                <div className="product-meta">
                  <h3 className="product-name">{displayName(product)}</h3>
                  <div className="product-category" dir="rtl">{product.category === 'Kitchen' || product.category === 'Home' ? 'أدوات منزلية' : product.category === 'Carry' ? 'أزياء وملابس' : 'عناية شخصية'}</div>
                  <p className="product-description">{displayDescription(product)}</p>
                  <div className="product-price-row"><strong data-testid={`text-price-${product.id}`}>{money(product.price)}</strong><span>السعر بالدولار الأمريكي</span></div>
                  <div className="product-buttons">
                    <button className="add-to-cart" type="button" onClick={() => addToCart(product)} data-testid={`button-add-${product.id}`}><ShoppingBag size={14} /> أضف إلى السلة</button>
                    <a className="product-whatsapp" href={whatsappHref(phone, productMessage(product))} target="_blank" rel="noreferrer" aria-label={`استفسر عن ${displayName(product)} عبر واتساب`} data-testid={`link-whatsapp-${product.id}`}><MessageCircle size={17} /></a>
                  </div>
                </div>
              </article>
            )) : (
              <div className="catalog-empty" data-testid="status-no-products">
                <div className="empty-symbol"><PackageCheck size={24} /></div>
                <h3>{search ? 'لا توجد نتائج مطابقة' : 'لا توجد منتجات مسجلة في هذه الفئة حالياً'}</h3>
                <p>{search ? 'جرّب كلمة بحث أخرى أو أزل عوامل التصفية.' : 'هذه الفئة معروضة للتصفح، وسيظهر فيها المنتج عند توفر سجل له في الكتالوج المحلي.'}</p>
                <button type="button" onClick={() => { setSearch(''); setActiveCategory('all'); }} data-testid="button-clear-empty">عرض الكتالوج المحلي</button>
              </div>
            )}
          </div>
        </div>
        <aside className="service-panel" id="services" aria-label="معلومات متجر قزان">
          <div className="service-logo"><img src={assetUrl('branding/qazan-logo.webp')} alt="" /></div>
          <h2>اختياراتك أقرب<br />مع متجر قزان</h2>
          <p className="service-subtitle">تواصل معنا للاستفسار عن المنتجات</p>
          <ul className="service-list">
            <li><span className="service-icon"><ShieldCheck size={16} /></span><span>كتالوج محلي واضح</span><b>✓</b></li>
            <li><span className="service-icon"><MessageCircle size={16} /></span><span>التواصل مباشرة عبر واتساب</span><b>✓</b></li>
            <li><span className="service-icon"><Truck size={16} /></span><span>تأكيد تفاصيل التوصيل قبل الطلب</span><b>✓</b></li>
            <li><span className="service-icon"><Headphones size={16} /></span><span>اسألنا عن المنتج الذي تريده</span><b>✓</b></li>
          </ul>
          <a className="service-contact" href={whatsappHref(phone, 'مرحباً متجر قزان، أود الاستفسار عن المنتجات.')} target="_blank" rel="noreferrer"><MessageCircle size={17} /> تواصل معنا عبر واتساب</a>
          <p className="disclosure">المنتجات والأسعار بيانات ثابتة داخل الواجهة ولا تتصل بإدارة مخزون. يُرجى تأكيد السعر والتوفر والتوصيل وطرق الدفع عبر واتساب.</p>
        </aside>
      </section>

      <section className="trust-strip qazan-wrap" aria-label="معلومات التسوق">
        <div><ShieldCheck size={18} /><span><strong>بيانات واضحة</strong><small>الكتالوج محلي وثابت</small></span></div>
        <div><ShoppingBag size={18} /><span><strong>سلة قابلة للتعديل</strong><small>تحكم بالكميات قبل الإرسال</small></span></div>
        <div><MessageCircle size={18} /><span><strong>تواصل مباشر</strong><small>الاستفسار وإرسال الطلب عبر واتساب</small></span></div>
        <div><Truck size={19} /><span><strong>تفاصيل التوصيل</strong><small>تُؤكد عبر واتساب قبل الطلب</small></span></div>
      </section>

      <footer className="qazan-footer" id="footer">
        <div className="qazan-wrap footer-content">
          <div className="footer-brand-block"><img src={assetUrl('branding/qazan-logo.webp')} alt="متجر قزان" /><p>متجر قزان — للتسوق والتواصل المباشر حول المنتجات.</p></div>
          <div className="footer-links"><strong>روابط سريعة</strong><a href="#shop">جميع المنتجات</a><a href="#categories">التصنيفات</a><a href="#services">عن المتجر</a></div>
          <div className="footer-contact"><strong>تواصل معنا</strong><p>الاستفسارات وتأكيد الطلبات عبر واتساب.</p>{phone ? <button type="button" onClick={openSettings} data-testid="button-edit-footer-number">تعديل الرقم المحفوظ</button> : <button type="button" onClick={openSettings} data-testid="button-configure-footer-number">إعداد رقم واتساب لهذا المتصفح</button>}</div>
        </div>
        <div className="qazan-wrap footer-bottom"><span>متجر قزان</span><span>المنتجات والسلة ورقم واتساب محفوظة محلياً في هذا المتصفح.</span></div>
      </footer>

      {cartCount > 0 && <button className="mobile-cart-fab" type="button" onClick={() => setCartOpen(true)} aria-label={`فتح السلة وفيها ${cartCount} منتجات`}><ShoppingBag size={18} /><span>السلة</span><b>{cartCount}</b><strong>{money(cartTotal)}</strong></button>}

      {cartOpen && <div className="qazan-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setCartOpen(false); }} data-testid="overlay-cart">
        <aside className="qazan-cart" role="dialog" aria-modal="true" aria-labelledby="cart-title" data-testid="panel-cart">
          <div className="drawer-head"><div><span className="drawer-kicker">متجر قزان</span><h2 id="cart-title">سلة التسوق <small>({cartCount})</small></h2></div><button type="button" onClick={() => setCartOpen(false)} className="close-control" aria-label="إغلاق السلة" data-testid="button-close-cart"><X size={20} /></button></div>
          {cartProducts.length ? <>
            <div className="drawer-items" data-testid="list-cart-items">{cartProducts.map(({ product, quantity }) => <div className="drawer-product" key={product.id} data-testid={`row-cart-${product.id}`}>
              <img src={product.image} alt="" /><div className="drawer-product-copy"><h3>{displayName(product)}</h3><span>{money(product.price)} للقطعة</span><div className="quantity-control" aria-label={`كمية ${displayName(product)}`}><button type="button" onClick={() => changeQuantity(product.id, -1)} aria-label={`تقليل كمية ${displayName(product)}`} data-testid={`button-decrease-${product.id}`}><Minus size={13} /></button><span data-testid={`text-quantity-${product.id}`}>{quantity}</span><button type="button" onClick={() => changeQuantity(product.id, 1)} aria-label={`زيادة كمية ${displayName(product)}`} data-testid={`button-increase-${product.id}`}><Plus size={13} /></button></div></div><button className="remove-product" type="button" onClick={() => removeFromCart(product.id)} aria-label={`حذف ${displayName(product)} من السلة`} data-testid={`button-remove-${product.id}`}><Trash2 size={16} /></button>
            </div>)}</div>
            <div className="cart-summary"><div className="total-line"><span>الإجمالي المقدر</span><strong data-testid="text-cart-total">{money(cartTotal)}</strong></div><p>التوفر والتوصيل والدفع يتم تأكيدها عبر واتساب.</p><a className="cart-checkout" href={whatsappHref(phone, cartMessage())} target="_blank" rel="noreferrer" data-testid="button-whatsapp-checkout"><MessageCircle size={18} /> متابعة الطلب عبر واتساب</a>{!phone && <div className="number-note">لم يتم حفظ رقم للمتجر بعد؛ سيفتح واتساب لاختيار جهة الاتصال. <button type="button" onClick={openSettings} data-testid="button-set-number-cart">إعداد رقم</button></div>}</div>
          </> : <div className="cart-empty" data-testid="status-empty-cart"><ShoppingBag size={28} /><h3>سلتك فارغة حالياً</h3><p>أضف منتجاً من الكتالوج المحلي للبدء.</p><button type="button" onClick={() => setCartOpen(false)} data-testid="button-continue-shopping">متابعة التسوق</button></div>}
        </aside>
      </div>}

      {favoritesOpen && <div className="qazan-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setFavoritesOpen(false); }} data-testid="overlay-favorites">
        <aside className="qazan-cart" role="dialog" aria-modal="true" aria-labelledby="favorites-title" data-testid="panel-favorites">
          <div className="drawer-head"><div><span className="drawer-kicker">محفوظة في هذا المتصفح</span><h2 id="favorites-title">المفضلة <small>({favoriteProducts.length})</small></h2></div><button type="button" onClick={() => setFavoritesOpen(false)} className="close-control" aria-label="إغلاق المفضلة" data-testid="button-close-favorites"><X size={20} /></button></div>
          {favoriteProducts.length ? <div className="drawer-items" data-testid="list-favorites">{favoriteProducts.map((product) => <div className="drawer-product favorite-product" key={product.id}>
            <img src={product.image} alt="" />
            <div className="drawer-product-copy"><h3>{displayName(product)}</h3><span>{money(product.price)}</span><button className="favorite-add" type="button" onClick={() => addToCart(product)} data-testid={`button-add-favorite-${product.id}`}><ShoppingBag size={13} /> أضف إلى السلة</button></div>
            <button className="remove-product" type="button" onClick={() => toggleFavorite(product)} aria-label={`إزالة ${displayName(product)} من المفضلة`} data-testid={`button-remove-favorite-${product.id}`}><X size={16} /></button>
          </div>)}</div> : <div className="cart-empty" data-testid="status-empty-favorites"><Heart size={28} /><h3>قائمتك فارغة</h3><p>أضف المنتجات إلى المفضلة من بطاقاتها.</p><button type="button" onClick={() => setFavoritesOpen(false)} data-testid="button-continue-from-favorites">متابعة التسوق</button></div>}
        </aside>
      </div>}

      {settingsOpen && <div className="qazan-overlay centered" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSettingsOpen(false); }}>
        <form className="qazan-settings" role="dialog" aria-modal="true" aria-labelledby="settings-title" onSubmit={savePhone} data-testid="dialog-whatsapp-settings">
          <div className="settings-heading"><span className="settings-icon"><MessageCircle size={20} /></span><button type="button" onClick={() => setSettingsOpen(false)} aria-label="إغلاق الإعدادات"><X size={19} /></button></div>
          <h2 id="settings-title">رقم واتساب المتجر</h2><p>أدخل رقم واتساب مع مفتاح الدولة. يُحفظ الرقم في هذا المتصفح فقط ولا يغيّر إعدادات المتجر العامة.</p>
          <label htmlFor="business-phone">رقم واتساب</label><input className="settings-input" id="business-phone" type="tel" value={phoneDraft} onChange={(event) => setPhoneDraft(event.target.value)} placeholder="+967 7XX XXX XXX" autoComplete="tel" dir="ltr" data-testid="input-business-number" />
          <span className="settings-hint">يمكنك ترك الحقل فارغاً لاختيار جهة الاتصال يدوياً في واتساب.</span>
          <div className="settings-buttons"><button type="button" className="settings-cancel" onClick={() => setSettingsOpen(false)} data-testid="button-cancel-settings">إلغاء</button><button className="settings-save" type="submit" data-testid="button-save-settings">{phoneDraft.trim() ? <><Check size={16} /> حفظ الرقم</> : 'المتابعة بدون رقم'}</button></div>
        </form>
      </div>}

      {compareOpen && <div className="qazan-overlay centered" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setCompareOpen(false); }}>
        <section className="qazan-compare" role="dialog" aria-modal="true" aria-labelledby="compare-title">
          <div className="compare-head"><div><span className="drawer-kicker">محفوظ محلياً</span><h2 id="compare-title">مقارنة المنتجات</h2></div><button className="close-control" type="button" onClick={() => setCompareOpen(false)} aria-label="إغلاق المقارنة"><X size={20} /></button></div>
          {comparedProducts.length ? <div className="compare-list">{comparedProducts.map((product) => <article className="compare-item" key={product.id}><img src={product.image} alt="" /><div><h3>{displayName(product)}</h3><strong>{money(product.price)}</strong></div><button type="button" onClick={() => setCompared((current) => current.filter((id) => id !== product.id))} aria-label={`إزالة ${displayName(product)} من المقارنة`}><X size={16} /></button></article>)}</div> : <div className="compare-empty"><Scale size={26} /><p>لم تضف منتجات للمقارنة بعد.</p><span>استخدم رمز المقارنة على بطاقات المنتجات.</span></div>}
          <p className="compare-note">المقارنة هنا تقتصر على المنتجات المسجلة في هذا الكتالوج المحلي.</p>
        </section>
      </div>}

      {toast && <div className="qazan-toast" role="status" aria-live="polite" data-testid="status-toast">{toast}</div>}
    </main>
  );
}
